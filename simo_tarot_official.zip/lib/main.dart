import 'dart:io';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const SimoTarotApp());
}

class SimoTarotApp extends StatelessWidget {
  const SimoTarotApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'سيمو تاروت',
      debugShowCheckedModeBanner: false,
      home: const Directionality(textDirection: TextDirection.rtl, child: SplashPage()),
    );
  }
}

class SplashPage extends StatefulWidget {
  const SplashPage({Key? key}) : super(key: key);
  @override State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  @override void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(seconds: 3));
    _ctrl.forward();
    Future.delayed(const Duration(milliseconds: 3200), () {
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const HomePage()));
    });
  }
  @override void dispose() { _ctrl.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) {
    return Scaffold(body: Container(decoration: const BoxDecoration(gradient: LinearGradient(colors: [Color(0xFFBEE6FF), Color(0xFF0A4C8A)], begin: Alignment.topCenter, end: Alignment.bottomCenter)), child: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [Container(width:160,height:160,decoration: BoxDecoration(shape:BoxShape.circle,boxShadow:[BoxShadow(color:Colors.black26,blurRadius:8)]), child: Center(child: SvgPicture.asset('assets/svgs/phoenix.svg', width:140, height:140))), const SizedBox(height:16), Text('سيمو تاروت', style: TextStyle(color: Colors.amber[200], fontSize:26, fontWeight: FontWeight.bold, shadows: [Shadow(blurRadius:4,color:Colors.black26)]))],),),),);
  }
}

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);
  @override State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  int balance = 0;
  final services = <Map<String,dynamic>>[
    {'name':'تاروت غجري','price':30000},
    {'name':'تاروت','price':20000},
    {'name':'كف','price':15000},
    {'name':'فنجان','price':10000},
    {'name':'كشف مستقبل','price':50000},
    {'name':'توافق','price':20000},
    {'name':'كشف خيانة','price':15000},
    {'name':'كشف نصيب','price':20000},
    {'name':'برج روحاني','price':5000},
  ];
  late AnimationController orbitCtrl;
  late Animation<double> orbitAnim;

  @override void initState() {
    super.initState();
    orbitCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 3));
    orbitAnim = CurvedAnimation(parent: orbitCtrl, curve: Curves.easeInOut);
    orbitCtrl.forward();
    _loadState();
  }
  Future<void> _loadState() async {
    final sp = await SharedPreferences.getInstance();
    setState(() { balance = sp.getInt('balance') ?? 0; });
  }
  @override void dispose() { orbitCtrl.dispose(); super.dispose(); }

  void _openService(Map<String,dynamic> svc) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => ServicePage(service: svc)));
  }
  void _openOrders() { Navigator.of(context).push(MaterialPageRoute(builder: (_) => OrdersPage())); }
  void _openVoiceManager() { Navigator.of(context).push(MaterialPageRoute(builder: (_) => VoiceManagerPage())); }
  void _openCharge() {
    showDialog(context: context, builder: (_) => AlertDialog(title: const Text('شحن المحفظة'), content: const Text('حول المبلغ إلى كود سيريتيل كاش: 36155155 ثم استخدم شاشة الشحن.'), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('حسناً'))]));
  }

  @override Widget build(BuildContext context) {
    return Scaffold(body: Container(decoration: const BoxDecoration(gradient: LinearGradient(colors: [Color(0xFFBEE6FF), Color(0xFF0A4C8A)], begin: Alignment.topCenter, end: Alignment.bottomCenter)), child: SafeArea(child: Padding(padding: const EdgeInsets.all(12), child: Column(children: [
      Row(children: [Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('سيمو تاروت', style: TextStyle(fontSize:26,fontWeight:FontWeight.bold,color:Colors.amber[200])), SizedBox(height:6), Text('اكتشف أسرار مستقبلك', style: TextStyle(color: Colors.amber[100]))])), Column(children: [Container(padding: EdgeInsets.symmetric(horizontal:10,vertical:6), decoration: BoxDecoration(color: Colors.white24,borderRadius: BorderRadius.circular(12)), child: Row(children: [Icon(Icons.account_balance_wallet,color:Colors.white), SizedBox(width:6), Text('الرصيد: ${NumberFormat('#,###','ar_SA').format(balance)} ل.س', style: TextStyle(color:Colors.white))])), SizedBox(height:8), ElevatedButton.icon(onPressed: _openCharge, icon: Icon(Icons.add_circle_outline), label: Text('شحن'), style: ElevatedButton.styleFrom(backgroundColor: Colors.amber[200], foregroundColor: Colors.black))])]), SizedBox(height:12),
      SizedBox(height:260, child: Stack(alignment: Alignment.center, children: [
        Positioned.fill(child: Opacity(opacity:0.6, child: SvgPicture.asset('assets/svgs/tarot_leaf.svg', fit: BoxFit.cover))),
        SvgPicture.asset('assets/svgs/phoenix.svg', width:180, height:180),
        AnimatedBuilder(animation: orbitAnim, builder: (context, child){
          final angle = orbitAnim.value * 2 * pi;
          final radius = 110.0;
          final dx = radius * 0.7 * cos(angle);
          final dy = radius * sin(angle);
          return Transform.translate(offset: Offset(dx, dy), child: Opacity(opacity:0.95, child: SvgPicture.asset('assets/svgs/sun.svg', width:48, height:48)));
        }),
        AnimatedBuilder(animation: orbitAnim, builder: (context, child){
          final angle = orbitAnim.value * 2 * pi + pi;
          final radius = 110.0;
          final dx = radius * 0.7 * cos(angle);
          final dy = radius * sin(angle);
          return Transform.translate(offset: Offset(dx, dy), child: Opacity(opacity:0.95, child: SvgPicture.asset('assets/svgs/moon.svg', width:44, height:44)));
        }),
      ])),
      SizedBox(height:8),
      Expanded(child: GridView.count(crossAxisCount:2, childAspectRatio:1.05, crossAxisSpacing:10, mainAxisSpacing:10, children: services.map((s){
        return GestureDetector(onTap: () => _openService(s), child: Container(decoration: BoxDecoration(color: Colors.white.withOpacity(0.06), borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.white24)), padding: EdgeInsets.all(12), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Expanded(child: Center(child: Text(s['name'], textAlign: TextAlign.center, style: TextStyle(color: Colors.amber[200], fontSize:18, fontWeight: FontWeight.bold)))), SizedBox(height:6), Text('السعر: ${NumberFormat('#,###','ar_SA').format(s['price'])} ل.س', style: TextStyle(color: Colors.white70)), SizedBox(height:8), Container(padding: EdgeInsets.symmetric(horizontal:10, vertical:6), decoration: BoxDecoration(color: Colors.amber[100], borderRadius: BorderRadius.circular(8)), child: Text('اطلب الآن', style: TextStyle(color: Colors.black))) ])),).toList())),
      Row(children: [Expanded(child: ElevatedButton.icon(onPressed: _openOrders, icon: Icon(Icons.history), label: Text('سجل الطلبات'), style: ElevatedButton.styleFrom(backgroundColor: Colors.white24, foregroundColor: Colors.white))), SizedBox(width:10), ElevatedButton.icon(onPressed: _openVoiceManager, icon: Icon(Icons.mic), label: Text('رفع صوتي'), style: ElevatedButton.styleFrom(backgroundColor: Colors.amber[200], foregroundColor: Colors.black))]),
    ])))));
  }
}

class ServicePage extends StatefulWidget {
  final Map<String,dynamic> service;
  const ServicePage({Key? key, required this.service}) : super(key: key);
  @override State<ServicePage> createState() => _ServicePageState();
}

class _ServicePageState extends State<ServicePage> {
  final _name = TextEditingController();
  final _mother = TextEditingController();
  DateTime? _birth;
  final _partner = TextEditingController();
  DateTime? _partnerBirth;
  final ImagePicker _picker = ImagePicker();
  List<XFile?> images = [null,null,null,null];
  XFile? voiceFile;

  Future<void> _pickImage(int i) async {
    final XFile? f = await _picker.pickImage(source: ImageSource.gallery, imageQuality: 70);
    if(f!=null) setState(()=> images[i]=f);
  }
  Future<void> _pickVoice() async {
    final XFile? f = await _picker.pickVideo(source: ImageSource.gallery);
    if(f!=null) setState(()=> voiceFile=f);
  }

  void _send() {
    if(_name.text.trim().isEmpty || _mother.text.trim().isEmpty || _birth==null) {
      _show('الرجاء ملء الاسم، اسم الأم وتحديد تاريخ الميلاد.');
      return;
    }
    final id = 'ORD-' + DateTime.now().millisecondsSinceEpoch.toString();
    final order = {'id': id, 'service': widget.service['name'], 'amount': widget.service['price'], 'name': _name.text.trim(), 'mother': _mother.text.trim(), 'birth': _birth!.toIso8601String(), 'partner': _partner.text.trim(), 'partnerBirth': _partnerBirth?.toIso8601String() ?? '', 'images': images.where((e)=> e!=null).map((e)=> e!.path).toList(), 'voice': voiceFile?.path ?? '', 'date': DateTime.now().toIso8601String(), 'status': 'قيد المراجعة'};
    _saveOrder(order);
    showDialog(context: context, builder: (_) => AlertDialog(title: Text('تم'), content: Text('تم استلام طلبك بنجاح. رقم الطلب: $id'), actions: [TextButton(onPressed: ()=> Navigator.pop(context), child: Text('حسناً'))]));
  }

  Future<void> _saveOrder(Map<String,dynamic> order) async {
    final sp = await SharedPreferences.getInstance();
    final list = sp.getStringList('orders') ?? [];
    list.insert(0, order.toString());
    await sp.setStringList('orders', list);
  }

  void _show(String m) => showDialog(context: context, builder: (_) => AlertDialog(title: Text('ملاحظة'), content: Text(m), actions: [TextButton(onPressed: ()=> Navigator.pop(context), child: Text('حسناً'))]));

  @override Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: Text(widget.service['name'], style: TextStyle(color: Colors.amber[200])), backgroundColor: Colors.transparent, elevation: 0, iconTheme: IconThemeData(color: Colors.white)), backgroundColor: Colors.transparent, body: Padding(padding: EdgeInsets.all(12), child: ListView(children: [Card(color: Colors.white24, child: Padding(padding: EdgeInsets.all(12), child: Column(children: [Text('أدخل بياناتك', style: TextStyle(color: Colors.amber[200], fontWeight: FontWeight.bold)), SizedBox(height:8), TextField(controller: _name, decoration: InputDecoration(label: Text('الاسم الكامل'), filled: true, fillColor: Colors.white)), SizedBox(height:8), TextField(controller: _mother, decoration: InputDecoration(label: Text('اسم الأم'), filled: true, fillColor: Colors.white)), SizedBox(height:8), Row(children: [Expanded(child: Text(_birth==null? 'تاريخ الميلاد: لم يحدد' : 'تاريخ الميلاد: ${DateFormat('yyyy-MM-dd').format(_birth!)}')), ElevatedButton(onPressed: () async { final d = await showDatePicker(context: context, initialDate: DateTime(1990), firstDate: DateTime(1900), lastDate: DateTime.now()); if(d!=null) setState(()=> _birth=d); }, child: Text('اختر'))]), if(widget.service['name']=='توافق' || widget.service['name']=='كشف خيانة') ...[ SizedBox(height:8), TextField(controller: _partner, decoration: InputDecoration(label: Text('اسم الشريك'), filled: true, fillColor: Colors.white)), SizedBox(height:8), Row(children: [Expanded(child: Text(_partnerBirth==null? 'تاريخ ميلاد الشريك: لم يحدد' : 'تاريخ ميلاد الشريك: ${DateFormat('yyyy-MM-dd').format(_partnerBirth!)}')), ElevatedButton(onPressed: () async { final d = await showDatePicker(context: context, initialDate: DateTime(1990), firstDate: DateTime(1900), lastDate: DateTime.now()); if(d!=null) setState(()=> _partnerBirth=d); }, child: Text('اختر'))]) ], if(widget.service['name']=='فنجان' || widget.service['name']=='كف') ...[ SizedBox(height:8), Text('رفع صور (يفضل 4 صور)'), SizedBox(height:8), Wrap(spacing:8, children: List.generate(4, (i)=> GestureDetector(onTap: ()=> _pickImage(i), child: Container(width:80,height:80,decoration: BoxDecoration(border: Border.all(color: Colors.white24), borderRadius: BorderRadius.circular(8), color: Colors.white12), child: images[i]==null? Center(child: Text('صورة ${i+1}', style: TextStyle(color: Colors.white54))) : Image.file(File(images[i]!.path), fit: BoxFit.cover)))))], SizedBox(height:12), ElevatedButton.icon(onPressed: _pickVoice, icon: Icon(Icons.mic), label: Text('إرفاق ملف صوتي (MP3)')), SizedBox(height:12), ElevatedButton(onPressed: _send, child: Text('إرسال الطلب'))]))])));
  }
}

class OrdersPage extends StatefulWidget { const OrdersPage({Key? key}) : super(key: key); @override State<OrdersPage> createState() => _OrdersPageState(); }
class _OrdersPageState extends State<OrdersPage> { List<String> list = []; @override void initState(){ super.initState(); _load(); } Future<void> _load() async { final sp = await SharedPreferences.getInstance(); setState(()=> list = sp.getStringList('orders') ?? []); } @override Widget build(BuildContext context) { return Scaffold(appBar: AppBar(title: Text('سجل الطلبات'), backgroundColor: Colors.transparent, elevation: 0, iconTheme: IconThemeData(color: Colors.white)), backgroundColor: Colors.transparent, body: Padding(padding: EdgeInsets.all(12), child: list.isEmpty? Center(child: Text('لا توجد طلبات بعد', style: TextStyle(color: Colors.white70))) : ListView.builder(itemCount: list.length, itemBuilder: (c,i){ final item = list[i]; return Card(color: Colors.white12, child: ListTile(title: Text(item.substring(0, item.indexOf(',')), style: TextStyle(color: Colors.amber[200])), subtitle: Text(item), isThreeLine: true); }))); } }
class VoiceManagerPage extends StatefulWidget { const VoiceManagerPage({Key? key}) : super(key: key); @override State<VoiceManagerPage> createState() => _VoiceManagerPageState(); }
class _VoiceManagerPageState extends State<VoiceManagerPage> { XFile? picked; final ImagePicker _picker = ImagePicker(); Future<void> _pickFile() async { final XFile? f = await _picker.pickVideo(source: ImageSource.gallery); if(f!=null) setState(()=> picked=f); } void _uploadForOrder() { if(picked==null) { showDialog(context: context, builder: (_) => AlertDialog(title: Text('ملاحظة'), content: Text('اختر ملف صوتي أولاً'), actions: [TextButton(onPressed: () => Navigator.pop(context), child: Text('حسناً'))])); return; } showDialog(context: context, builder: (_) => AlertDialog(title: Text('تم'), content: Text('تم حفظ الملف محلياً (MVP).'), actions: [TextButton(onPressed: () => Navigator.pop(context), child: Text('حسناً'))])); } @override Widget build(BuildContext context) { return Scaffold(appBar: AppBar(title: Text('رفع رد صوتي'), backgroundColor: Colors.transparent, elevation: 0, iconTheme: IconThemeData(color: Colors.white)), backgroundColor: Colors.transparent, body: Padding(padding: EdgeInsets.all(12), child: Column(children: [Card(color: Colors.white24, child: Padding(padding: EdgeInsets.all(12), child: Column(children: [Text('ارفع تسجيل صوتي لك (MP3 أو M4A)'), SizedBox(height:8), ElevatedButton.icon(onPressed: _pickFile, icon: Icon(Icons.upload_file), label: Text('اختر ملف من الهاتف')), if(picked!=null) Text('تم اختيار: ${picked!.name}'), SizedBox(height:12), ElevatedButton(onPressed: _uploadForOrder, child: Text('حفظ الملف'))]))]))); } }